# SimplePay

A small Paper (1.21) plugin with a working player-to-player economy.

## Commands

| Command | Description | Permission |
| --- | --- | --- |
| `/pay [player] [amount]` | Send money to an online player | `simplepay.pay` (default: everyone) |
| `/balance [player]` (`/bal`, `/money`) | Show your balance or another player's | `simplepay.balance` (default: everyone) |
| `/eco give\|take\|set [player] [amount]` | Adjust a balance | `simplepay.admin` (default: op) |
| `/eco reload` | Reload `config.yml` | `simplepay.admin` |

Amounts accept shorthand: `500`, `1.5k`, `2m`, `3b`.

## Build

Requires JDK 21 and Maven.

```
mvn package
```

Copy `target/SimplePay-1.0.0.jar` into your server's `plugins/` folder and restart.

## Configuration

`config.yml` controls the starting balance, minimum payment, cooldown, and every message
(MiniMessage format). Balances are stored in `plugins/SimplePay/balances.yml`.
