package com.example.simplepay;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * A small working economy: /pay moves real balances between players,
 * /balance shows them, /eco lets admins seed or adjust money.
 * Balances are whole numbers and are saved to plugins/SimplePay/balances.yml.
 */
public final class SimplePay extends JavaPlugin implements Listener, TabExecutor {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final String[] SUFFIXES = {"", "K", "M", "B", "T"};
    private static final Sound PAY_SOUND =
            Sound.sound(Key.key("entity.experience_orb.pickup"), Sound.Source.PLAYER, 1.0f, 1.2f);

    private final Map<UUID, Long> balances = new HashMap<>();
    private final Map<UUID, Long> lastPay = new HashMap<>();

    private File dataFile;
    private ExecutorService io;
    private boolean savePending;

    private long startingBalance;
    private long minPay;
    private long cooldownMillis;

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        readSettings();
        dataFile = new File(getDataFolder(), "balances.yml");
        io = Executors.newSingleThreadExecutor();
        loadBalances();

        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("pay", "balance", "eco")) {
            PluginCommand cmd = getCommand(name);
            if (cmd != null) {
                cmd.setExecutor(this);
                cmd.setTabCompleter(this);
            }
        }
    }

    @Override
    public void onDisable() {
        io.shutdown();
        try {
            io.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        writeFile(snapshot());
    }

    private void readSettings() {
        startingBalance = Math.max(0L, getConfig().getLong("starting-balance", 0L));
        minPay = Math.max(1L, getConfig().getLong("min-pay", 1L));
        cooldownMillis = Math.max(0L, getConfig().getLong("cooldown-seconds", 0L)) * 1000L;
    }

    // ------------------------------------------------------------------ storage

    private void loadBalances() {
        if (!dataFile.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : yaml.getKeys(false)) {
            try {
                balances.put(UUID.fromString(key), Math.max(0L, yaml.getLong(key)));
            } catch (IllegalArgumentException ignored) {
                getLogger().warning("Skipping invalid entry in balances.yml: " + key);
            }
        }
    }

    /** Must be called on the main thread. */
    private String snapshot() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<UUID, Long> e : balances.entrySet()) {
            yaml.set(e.getKey().toString(), e.getValue());
        }
        return yaml.saveToString();
    }

    private synchronized void writeFile(String data) {
        try {
            getDataFolder().mkdirs();
            File tmp = new File(getDataFolder(), "balances.yml.tmp");
            Files.writeString(tmp.toPath(), data, StandardCharsets.UTF_8);
            Files.move(tmp.toPath(), dataFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            getLogger().severe("Could not save balances: " + e.getMessage());
        }
    }

    /** Batches changes: saves about two seconds after the first change. Main thread only. */
    private void scheduleSave() {
        if (savePending) {
            return;
        }
        savePending = true;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            savePending = false;
            String data = snapshot();
            io.execute(() -> writeFile(data));
        }, 40L);
    }

    private long balanceOf(UUID id) {
        return balances.getOrDefault(id, startingBalance);
    }

    // ------------------------------------------------------------------ events

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (balances.putIfAbsent(event.getPlayer().getUniqueId(), startingBalance) == null) {
            scheduleSave();
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        lastPay.remove(event.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "pay" -> handlePay(sender, args);
            case "balance" -> handleBalance(sender, args);
            case "eco" -> handleEco(sender, args);
            default -> {
                return false;
            }
        }
        return true;
    }

    private void handlePay(CommandSender sender, String[] args) {
        if (!(sender instanceof Player payer)) {
            send(sender, "players-only");
            return;
        }
        if (args.length != 2) {
            send(payer, "usage-pay");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            send(payer, "player-not-found", Placeholder.unparsed("player", args[0]));
            return;
        }
        if (target.getUniqueId().equals(payer.getUniqueId())) {
            send(payer, "cannot-pay-self");
            return;
        }

        Long parsed = parseAmount(args[1]);
        if (parsed == null || parsed <= 0) {
            send(payer, "invalid-amount");
            return;
        }
        long amount = parsed;
        if (amount < minPay) {
            send(payer, "below-minimum", Placeholder.unparsed("min", abbreviate(minPay)));
            return;
        }

        long now = System.currentTimeMillis();
        Long last = lastPay.get(payer.getUniqueId());
        if (cooldownMillis > 0 && last != null && now - last < cooldownMillis) {
            long secondsLeft = (cooldownMillis - (now - last) + 999L) / 1000L;
            send(payer, "on-cooldown", Placeholder.unparsed("seconds", String.valueOf(secondsLeft)));
            return;
        }

        long payerBalance = balanceOf(payer.getUniqueId());
        if (payerBalance < amount) {
            send(payer, "not-enough-money", Placeholder.unparsed("balance", abbreviate(payerBalance)));
            return;
        }

        long newTargetBalance;
        try {
            newTargetBalance = Math.addExact(balanceOf(target.getUniqueId()), amount);
        } catch (ArithmeticException e) {
            send(payer, "invalid-amount");
            return;
        }

        // The actual transfer: both balances change together, on the main thread.
        balances.put(payer.getUniqueId(), payerBalance - amount);
        balances.put(target.getUniqueId(), newTargetBalance);
        lastPay.put(payer.getUniqueId(), now);
        scheduleSave();

        send(payer, "pay-sent",
                Placeholder.unparsed("player", target.getName()),
                Placeholder.unparsed("amount", abbreviate(amount)));
        send(target, "pay-received",
                Placeholder.unparsed("player", payer.getName()),
                Placeholder.unparsed("amount", abbreviate(amount)));
        target.playSound(PAY_SOUND);

        getLogger().info(payer.getName() + " paid " + target.getName() + " $" + amount);
    }

    private void handleBalance(CommandSender sender, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                send(sender, "players-only");
                return;
            }
            send(player, "balance-self",
                    Placeholder.unparsed("balance", abbreviate(balanceOf(player.getUniqueId()))));
            return;
        }

        OfflinePlayer target = findPlayer(args[0]);
        if (target == null) {
            send(sender, "player-not-found", Placeholder.unparsed("player", args[0]));
            return;
        }
        String name = target.getName() != null ? target.getName() : args[0];
        send(sender, "balance-other",
                Placeholder.unparsed("player", name),
                Placeholder.unparsed("balance", abbreviate(balanceOf(target.getUniqueId()))));
    }

    private void handleEco(CommandSender sender, String[] args) {
        if (!sender.hasPermission("simplepay.admin")) {
            send(sender, "no-permission");
            return;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            readSettings();
            send(sender, "reloaded");
            return;
        }

        String action = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "";
        if (args.length != 3 || !List.of("give", "take", "set").contains(action)) {
            send(sender, "usage-eco");
            return;
        }

        OfflinePlayer target = findPlayer(args[1]);
        if (target == null) {
            send(sender, "player-not-found", Placeholder.unparsed("player", args[1]));
            return;
        }
        Long parsed = parseAmount(args[2]);
        if (parsed == null || parsed < 0) {
            send(sender, "invalid-amount");
            return;
        }
        long amount = parsed;

        UUID id = target.getUniqueId();
        long current = balanceOf(id);
        long result;
        try {
            result = switch (action) {
                case "give" -> Math.addExact(current, amount);
                case "take" -> Math.max(0L, current - amount);
                default -> amount; // "set"
            };
        } catch (ArithmeticException e) {
            send(sender, "invalid-amount");
            return;
        }

        balances.put(id, result);
        scheduleSave();

        String name = target.getName() != null ? target.getName() : args[1];
        send(sender, "eco-done",
                Placeholder.unparsed("player", name),
                Placeholder.unparsed("balance", abbreviate(result)));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "pay" -> {
                if (args.length == 1) return onlineNames(args[0]);
                if (args.length == 2) return filter(List.of("100", "1k", "10k", "100k", "1m"), args[1]);
            }
            case "balance" -> {
                if (args.length == 1) return onlineNames(args[0]);
            }
            case "eco" -> {
                if (!sender.hasPermission("simplepay.admin")) return List.of();
                if (args.length == 1) return filter(List.of("give", "take", "set", "reload"), args[0]);
                if (args.length == 2) return onlineNames(args[1]);
                if (args.length == 3) return filter(List.of("1k", "10k", "100k", "1m"), args[2]);
            }
            default -> { }
        }
        return List.of();
    }

    // ------------------------------------------------------------------ helpers

    private OfflinePlayer findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return online;
        }
        return Bukkit.getOfflinePlayerIfCached(name);
    }

    private List<String> onlineNames(String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        return Bukkit.getOnlinePlayers().stream()
                .map(Player::getName)
                .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(p))
                .toList();
    }

    private static List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        return options.stream().filter(o -> o.startsWith(p)).toList();
    }

    private void send(CommandSender to, String key, TagResolver... resolvers) {
        String raw = getConfig().getString("messages." + key, "<red>Missing message: " + key);
        to.sendMessage(MM.deserialize(raw, resolvers));
    }

    /** Accepts 500, 1,500, $2k, 1.5k, 2m, 3b, 1t. Returns null if invalid or not a whole number. */
    static Long parseAmount(String input) {
        String s = input.trim().toLowerCase(Locale.ROOT).replace(",", "");
        if (s.startsWith("$")) {
            s = s.substring(1);
        }
        if (s.isEmpty()) {
            return null;
        }

        BigDecimal multiplier = BigDecimal.ONE;
        switch (s.charAt(s.length() - 1)) {
            case 'k' -> multiplier = BigDecimal.valueOf(1_000L);
            case 'm' -> multiplier = BigDecimal.valueOf(1_000_000L);
            case 'b' -> multiplier = BigDecimal.valueOf(1_000_000_000L);
            case 't' -> multiplier = BigDecimal.valueOf(1_000_000_000_000L);
            default -> { }
        }
        if (multiplier.compareTo(BigDecimal.ONE) != 0) {
            s = s.substring(0, s.length() - 1);
        }
        if (!s.matches("\\d+(\\.\\d+)?")) {
            return null;
        }

        try {
            BigDecimal value = new BigDecimal(s).multiply(multiplier);
            if (value.stripTrailingZeros().scale() > 0) {
                return null; // fractions of a dollar aren't supported
            }
            return value.longValueExact();
        } catch (ArithmeticException e) {
            return null;
        }
    }

    /** 1500 -> 1.5K, 2000000 -> 2M. */
    static String abbreviate(long value) {
        double d = value;
        int i = 0;
        while (d >= 1000 && i < SUFFIXES.length - 1) {
            d /= 1000;
            i++;
        }
        String s = String.format(Locale.US, "%.2f", d);
        if (s.contains(".")) {
            s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        }
        return s + SUFFIXES[i];
    }
}
